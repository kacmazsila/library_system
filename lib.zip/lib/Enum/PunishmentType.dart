enum PunishmentType {
  money,
  block,
  publicService,
}
