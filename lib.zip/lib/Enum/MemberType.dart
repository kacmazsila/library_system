enum MemberType { Gold, Silver, Platinium, Starter, Student, Teacher }
