enum Category { Masal, Macera, Fantastik, Tarih, Aksiyon, BilimKurgu, Ask }
